package org.cap.model;

public class Customer {
	
	private int custId;
	private String firstName;
	private String lastName;
	private double regfee;
	private Address address;
	
	
	public Customer() {
		
	}
	
	

	public Customer(int custId, String firstName, String lastName, double regfee,Address address) {
		super();
		this.custId = custId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.regfee = regfee;
		this.address = address;
	}



	public int getCustId() {
		return custId;
	}



	public void setCustId(int custId) {
		this.custId = custId;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public double getRegfee() {
		return regfee;
	}



	public void setRegfee(double regfee) {
		this.regfee = regfee;
	}



	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", firstName=" + firstName + ", lastName=" + lastName + ", regfee="
				+ regfee + ", address=" + address + "]";
	}
	
	public void init() {
		System.out.println("init() method");
	}

	public void destroy() {
		System.out.println("destroy method");
	}
	
}
