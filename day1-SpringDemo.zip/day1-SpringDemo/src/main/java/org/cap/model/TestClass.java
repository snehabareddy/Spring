package org.cap.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestClass {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("myBeans.xml");
		Customer employee = (Customer)context.getBean("cust");

		System.out.println(employee);
		
		ApplicationContext context1 = new ClassPathXmlApplicationContext("myBeansCon.xml");
		Customer  employee1 = (Customer )context1.getBean("cust");

		System.out.println(employee1);
		
	}

}
